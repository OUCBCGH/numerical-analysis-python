# -*- coding: UTF-8 -*-
"""
@file_name: __init__.py.py
@time: 2021-11-09
@IDE: PyCharm  Python: 3.9.7
@copyright: http://maths.xynu.edu.cn
"""
